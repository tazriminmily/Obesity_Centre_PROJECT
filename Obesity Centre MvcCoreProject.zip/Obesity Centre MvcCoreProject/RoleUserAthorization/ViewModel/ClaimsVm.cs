﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.ViewModel
{
    public class ClaimsVm
    {

        public ClaimsVm()
        {
            UserClaims = new List<UserClaims>();
        }
        public string Email { get; set; }
        public List<UserClaims> UserClaims { get; set; }
    }
}

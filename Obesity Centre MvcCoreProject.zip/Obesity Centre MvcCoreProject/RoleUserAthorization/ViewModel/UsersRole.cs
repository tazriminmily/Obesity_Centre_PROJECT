﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.ViewModel
{
    public class UsersRoleVm
    {
        [Key]
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string RoleName { get; set; }
    }
    public class RoleVm
    {
        [Key]
        public string Id { get; set; }
        public string Name { get; set; }

    }
}

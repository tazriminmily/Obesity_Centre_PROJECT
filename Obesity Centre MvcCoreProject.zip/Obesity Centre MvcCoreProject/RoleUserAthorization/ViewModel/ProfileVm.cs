﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.ViewModel
{
    public class ProfileVm
    {
        public string Id { get; set; }
        public string UserName { get; set; }
       
        public string Email { get; set; }
        
        [DisplayName("Date of birth"), DataType(DataType.Date)]
        public DateTime DOB { get; set; }
        public string Picture { get; set; }
        [NotMapped]
        public IFormFile ImgFile { get; set; }


    }
}

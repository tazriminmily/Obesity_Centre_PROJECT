﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.ViewModel
{
    public class UserClaims
    {
      
        public bool Isselected { get; set; }
        public string  ClaimType { get; set; }
    }
}

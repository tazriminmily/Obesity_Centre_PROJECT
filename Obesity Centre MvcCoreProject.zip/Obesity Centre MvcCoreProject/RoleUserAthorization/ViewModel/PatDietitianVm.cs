﻿using ObesityCentreMvcCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.ViewModel
{
    public class PatDietitianVm
    {
        public string deititian { get; set; }
        public string phone { get; set; }
        public IList<Patient> Patients { get; set; }
    }
}

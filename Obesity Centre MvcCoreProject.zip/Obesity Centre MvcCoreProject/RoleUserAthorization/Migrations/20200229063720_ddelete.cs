﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ObesityCentreMvcCore.Migrations
{
    public partial class ddelete : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"Create PROC sp_delete @id INT
                                    AS
                                    BEGIN
                                    Delete From Disease_tbl Where id = @id
                                    END");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

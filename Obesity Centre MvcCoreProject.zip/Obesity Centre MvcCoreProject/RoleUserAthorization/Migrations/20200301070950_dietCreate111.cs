﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ObesityCentreMvcCore.Migrations
{
    public partial class dietCreate111 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"Create PROC sp_createDietitian
                                    @dietitianname NVARCHAR(MAX), @phone NVARCHAR(MAX),@addressid INT
                                    AS
                                    BEGIN
                                    insert into dietitian values ( @dietitianname,  @phone, @addressid)
                                    END");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

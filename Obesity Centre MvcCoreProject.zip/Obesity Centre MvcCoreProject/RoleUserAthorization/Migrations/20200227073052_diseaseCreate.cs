﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ObesityCentreMvcCore.Migrations
{
    public partial class diseaseCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.Sql(@"CREATE PROC sp_all
            //                        AS
            //                        BEGIN
            //                        SELECT * FROM Products
            //                        ORDER BY Name
            //                        END");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

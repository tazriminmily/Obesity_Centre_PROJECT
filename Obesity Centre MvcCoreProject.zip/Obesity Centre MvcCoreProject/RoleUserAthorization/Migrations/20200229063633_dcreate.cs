﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ObesityCentreMvcCore.Migrations
{
    public partial class dcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"Create PROC sp_create
                                    @diseasename NVARCHAR(MAX)
                                    AS
                                    BEGIN
                                    insert into Disease_tbl values (@diseasename)
                                    END");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

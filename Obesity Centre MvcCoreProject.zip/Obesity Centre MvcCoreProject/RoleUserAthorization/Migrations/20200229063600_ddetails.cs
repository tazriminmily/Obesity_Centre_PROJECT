﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ObesityCentreMvcCore.Migrations
{
    public partial class ddetails : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"CREATE PROC sp_details @id INT
                                    AS
                                    BEGIN
                                    SELECT * FROM Disease_tbl
                                    WHERE id = @id
                                    ORDER BY diseasename
                                    END");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

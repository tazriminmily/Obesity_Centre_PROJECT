﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ObesityCentreMvcCore.Migrations
{
    public partial class dupdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"CREATE PROC sp_update
                                    @diseasename NVARCHAR(MAX),@id INT
                                    AS
                                    BEGIN
                                    UPDATE Disease_tbl Set diseasename = @diseasename WHERE id = @id
                                    END");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

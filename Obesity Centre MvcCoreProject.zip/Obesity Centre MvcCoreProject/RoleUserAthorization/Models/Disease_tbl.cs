﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.Models
{
    public class Disease_tbl
    {
        public int id { get; set; }
        public string diseasename { get; set; }
        public ICollection<Patient> patients { get; set; }
    }
}

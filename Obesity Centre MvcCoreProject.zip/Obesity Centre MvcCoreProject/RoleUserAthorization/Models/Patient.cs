﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.Models
{
    public class Patient
    {
        public int id { get; set; }
        [StringLength(50, MinimumLength = 3)]
        [Required]
        public string pname { get; set; }
        [StringLength(50, MinimumLength = 3)]
        [Required]
        public string phone { get; set; }
        [Required]
        public int age { get; set; }
        [Required]
        public int height { get; set; }
        [Required]
        public int weight { get; set; }
        //[Required]
        public string photo { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime SerialDate { get; set; }
        [ForeignKey("Address_tbl")]
        public int addressid { get; set; }
        [Required]
        [ForeignKey("Disease_tbl")]
        public int diseaseid { get; set; }
        [ForeignKey("dietitian")]
        public int dietitianid { get; set; }

        public virtual Address_tbl address_tbl { get; set; }
        public virtual Disease_tbl disease_tbl { get; set; }
        public virtual dietitian dietitian { get; set; }

        [NotMapped]
        public IFormFile Imgfile { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ObesityCentreMvcCore.Models
{
    public class dietitian
    {
        public int id { get; set; }
        [StringLength(50, MinimumLength = 3)]
        [Required]
        public string dietitianname { get; set; }
        [StringLength(50, MinimumLength = 10)]
        [Required]
        public string phone { get; set; }
        [ForeignKey("Address_tbl")]
        public int addressid { get; set; }

        public virtual Address_tbl address_tbl { get; set; }

        public virtual ICollection<Patient> patients { get; set; }
    }
}

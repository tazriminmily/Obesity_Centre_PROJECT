﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ObesityCentreMvcCore.ViewModel;
using ObesityCentreMvcCore.Data;
namespace ObesityCentreMvcCore.Controllers
{
    public class ProfileController : Controller
    {
        private UserManager<ApplicationUser> userManager;
        private readonly IHostingEnvironment hosting;
        public ProfileController(UserManager<ApplicationUser> userManager, IHostingEnvironment hosting)
        {
            this.userManager = userManager;
            this.hosting = hosting;
        }
        [HttpGet]
        public IActionResult Index()
        {
            var users = userManager.Users;
            return View(users);
           

        }
        [HttpGet]
        public async Task<IActionResult> Profile(string id)
        {
            
            var user = await userManager.FindByIdAsync(id);
            if (user == null)
            {
                ViewBag.ErrorMessage = $"User with Id = {id} cannot be found";
                return View("NotFound");
            }
            var model = new ProfileVm
            {
                Id = user.Id,
                Email = user.Email,
                UserName = user.UserName,
                DOB = user.DOB,
                Picture = user.Picture,
               
            };
            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> Profile(ProfileVm model)
        {
            var user = await userManager.FindByIdAsync(model.Id);
            if (user == null)
            {
                ViewBag.ErrorMessage = $"User with Id = {model.Id} cannot be found";
                return View("NotFound");
            }
            else
            {
                if (model.ImgFile != null)
                {
                    string ext = Path.GetExtension(model.ImgFile.FileName).ToLower();
                    if (ext == ".jpg" || ext == ".png" || ext == ".jpeg")
                    {
                        var filename = Path.GetFileName(model.ImgFile.FileName);
                        var filePath = Path.Combine(hosting.WebRootPath, "images\\ProfilePic", filename);
                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            model.ImgFile.CopyTo(fileStream);
                            user.Picture = "\\images\\ProfilePic\\" + model.ImgFile.FileName;
                        }
                    }
                }
                user.Email = model.Email;
                user.UserName = model.UserName;
                user.DOB = model.DOB;
                var result = await userManager.UpdateAsync(user);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    foreach (var e in result.Errors)
                    {
                        ViewBag.result = e.Description;
                    }

                }
                return View(model);
            }

           

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ObesityCentreMvcCore.Data;
using ObesityCentreMvcCore.Models;
using ObesityCentreMvcCore.ViewModel;

namespace ObesityCentreMvcCore.Controllers
{
    public class AddresssController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AddresssController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public JsonResult Get()
        {
            var data = _context.address_Tbls.ToList();
            return Json(data);
        }
        public IActionResult AddAddress([Bind("Id,address")]AddressVM vm)
        {
            if (!ModelState.IsValid)
            {
                var list = new List<string>();
                foreach (var modelStateVal in ViewData.ModelState.Values)
                {
                    list.AddRange(modelStateVal.Errors.Select(error => error.ErrorMessage));
                }
                return Json(new { result = "error", errors = list });
            }


            Address_tbl addresstbl = new Address_tbl
            {
                address = vm.address,
                
            };

            _context.address_Tbls.Add(addresstbl);
            if (_context.SaveChanges() > 0)
            {
                return Json(new { result = "success" });
            }
            else
            {
                return Json(new { result = "failed" });
            }

        }
        public JsonResult GetByID(int id)
        {
            var ad = _context.address_Tbls.Find(id);

            return Json(ad);
        }
        public JsonResult Delete(int id)
        {
            var ad = _context.address_Tbls.Find(id);
            _context.address_Tbls.Remove(ad);
            if (_context.SaveChanges() > 0)
            {
                return Json(new { result = "successfully delete" });
            }


            return Json(new { result = "failed" });


        }
        public IActionResult UpdateAddress([Bind("Id,address")]AddressVM vm)
        {
            if (!ModelState.IsValid)
            {

                ModelState.AddModelError("", "Invalid Model");
                return View("Index", vm);
            }


            Address_tbl addresstbl = new Address_tbl
            {
                address = vm.address,
                Id = vm.Id,
            };

            _context.Entry(addresstbl).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            if (_context.SaveChanges() > 0)
            {
                return Json(new { result = "success" });
            }
            else
            {
                return Json(new { result = "failed" });
            }

        }
    }
}
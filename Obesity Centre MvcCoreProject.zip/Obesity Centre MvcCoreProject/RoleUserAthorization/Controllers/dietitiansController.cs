﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ObesityCentreMvcCore.Data;
using ObesityCentreMvcCore.Models;
using ObesityCentreMvcCore.ViewModel;

namespace ObesityCentreMvcCore.Controllers
{
    public class dietitiansController : Controller
    {
        private readonly ApplicationDbContext _context;

        public dietitiansController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: dietitians
        public async Task<IActionResult> Index(string searchString, string sortOrder, string currentFilter, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
           

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;
            var dietitians = from s in _context.dietitians
                           select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                dietitians = dietitians.Where(s => s.dietitianname.Contains(searchString));
            }
            switch (sortOrder)
            {
                case "name_desc":
                    dietitians = dietitians.OrderByDescending(s => s.dietitianname);
                    break;
               
                default:
                    dietitians = dietitians.OrderBy(s => s.dietitianname);
                    break;
            }
            int pageSize = 3;

            return View(await PaginatedList<dietitian>.CreateAsync(dietitians.AsNoTracking(), pageNumber ?? 1, pageSize));
        }
        public IActionResult GetAll()
        {
            ViewBag.dietitianid = new SelectList(_context.dietitians.ToList(), "id", "dietitianname", "phone", "addressid");
            List<PatDietitianVm> data = new List<PatDietitianVm>();
            foreach (dietitian dietitian in _context.dietitians)
            {
                data.Add(new PatDietitianVm
                {
                    deititian = dietitian.dietitianname,
                    phone = dietitian.phone,
                    Patients = _context.patients.Where(p => p.dietitianid == dietitian.id).ToList()
                });
            }
            return View(data);
        }
        // GET: dietitians/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dietitian = await _context.dietitians
                .FirstOrDefaultAsync(m => m.id == id);
            if (dietitian == null)
            {
                return NotFound();
            }

            return View(dietitian);
        }

        // GET: dietitians/Create
        //public IActionResult Create()
        //{
        //    return View();
        //}

        // POST: dietitians/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("id,dietitianname,phone,addressid")] dietitian dietitian)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(dietitian);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(dietitian);
        //}
        public IActionResult Create2()
        {
            //ViewData["addressid"] = new SelectList(_context.address_Tbls, "Id", "address");
            return View();
        }
        [HttpPost]
        public IActionResult Create2(dietitian dietitiann)
        {
            var proc = _context.Database.ExecuteSqlCommand("exec sp_createDietitian @dietitianname  = {0},@phone= {1}, @addressid={2}", dietitiann.dietitianname, dietitiann.phone,dietitiann.addressid);
            if (proc > 0)
            {
                return RedirectToAction("Index");
            }
            //ViewData["addressid"] = new SelectList(_context.address_Tbls, "Id", "address", dietitiann.addressid);
            return View(dietitiann);
        }


        [HttpPost]
        public IActionResult CreateMulti(List<dietitian> dietitianss)
        {
            if (dietitianss.Count > 0)
            {
                _context.AddRange(dietitianss);
                if (_context.SaveChanges() > 0)
                {
                    return RedirectToAction("Index");
                }

            }
         
            return View(dietitianss);
        }

        // GET: dietitians/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dietitian = await _context.dietitians.FindAsync(id);
            if (dietitian == null)
            {
                return NotFound();
            }
            return View(dietitian);
        }

        // POST: dietitians/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,dietitianname,phone,addressid")] dietitian dietitian)
        {
            if (id != dietitian.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dietitian);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!dietitianExists(dietitian.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dietitian);
        }

        // GET: dietitians/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dietitian = await _context.dietitians
                .FirstOrDefaultAsync(m => m.id == id);
            if (dietitian == null)
            {
                return NotFound();
            }

            return View(dietitian);
        }

        // POST: dietitians/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dietitian = await _context.dietitians.FindAsync(id);
            _context.dietitians.Remove(dietitian);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool dietitianExists(int id)
        {
            return _context.dietitians.Any(e => e.id == id);
        }
    }
}

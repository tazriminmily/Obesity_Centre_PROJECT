﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ObesityCentreMvcCore.Data;
using ObesityCentreMvcCore.Models;

namespace ObesityCentreMvcCore.Controllers
{
    public class DiseasesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DiseasesController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var proc = _context.Disease_tbl.FromSql<Disease_tbl>("sp_all");
            return View(proc);
        }
        public IActionResult Details(int id)
        {
            var proc = _context.Disease_tbl.FromSql<Disease_tbl>("sp_details @id = {0}", id).SingleOrDefault();
            return View(proc);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Disease_tbl disease)
        {
            var proc = _context.Database.ExecuteSqlCommand("exec sp_create @diseasename = {0}", disease.diseasename);
            if (proc > 0)
            {
                return RedirectToAction("Index");
            }
            return View(disease);
        }
        public IActionResult Edit(int id)
        {
            var proc = _context.Disease_tbl.FromSql<Disease_tbl>("sp_details @id = {0}", id).SingleOrDefault();
            return View(proc);
        }
        [HttpPost]
        public IActionResult Edit(Disease_tbl disease)
        {
            var proc = _context.Database.ExecuteSqlCommand("exec sp_update @diseasename = {0},@id = {1}", disease.diseasename,disease.id);
            if (proc > 0)
            {
                return RedirectToAction("Index");
            }
            return View(disease);
        }
        public IActionResult Delete(int id)
        {
            var proc = _context.Database.ExecuteSqlCommand("sp_delete @id = {0}", id);
            if (proc > 0)
            {
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}
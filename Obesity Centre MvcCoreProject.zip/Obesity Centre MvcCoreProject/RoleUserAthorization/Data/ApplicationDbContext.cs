﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ObesityCentreMvcCore.Models;
using ObesityCentreMvcCore.ViewModel;
using static ObesityCentreMvcCore.Data.ApplicationDbContext;

namespace ObesityCentreMvcCore.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        //public DbSet<ObesityCentreMvcCore.ViewModel.RoleVm> RoleVm { get; set; }
        //public DbSet<ObesityCentreMvcCore.ViewModel.UsersRoleVm> UsersRoleVm { get; set; }
        public DbSet<Address_tbl> address_Tbls { get; set; }
        public DbSet<dietitian> dietitians { get; set; }
        public DbSet<Patient> patients { get; set; }
        public DbSet<Disease_tbl> Disease_tbl { get; set; }
        



    }
    /////////for profile add//////
    public class ApplicationUser : IdentityUser
    {

        [DisplayName("Date of birth"), DataType(DataType.Date)]
        public DateTime DOB { get; set; }
        public string Picture { get; set; }

    }
}
